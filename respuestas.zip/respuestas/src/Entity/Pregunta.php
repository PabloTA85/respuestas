<?php

namespace App\Entity;

use App\Repository\PreguntaRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: PreguntaRepository::class)]
class Pregunta
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $descripcion = null;

    #[ORM\Column(length: 255)]
    private ?string $opcion1 = null;

    #[ORM\Column(length: 255)]
    private ?string $opcion2 = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $opcion3 = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $opcion4 = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $fecha_inicio = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $fecha_fin = null;

    #[ORM\Column(length: 255)]
    private ?string $opcion_correcta = null;

    /**
     * @var Collection<int, Respuesta>
     */
    #[ORM\OneToMany(targetEntity: Respuesta::class, mappedBy: 'id_pregunta', orphanRemoval: true)]
    private Collection $respuestas;

    public function __construct()
    {
        $this->respuestas = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDescripcion(): ?string
    {
        return $this->descripcion;
    }

    public function setDescripcion(string $descripcion): static
    {
        $this->enunciado = $descripcion;

        return $this;
    }

    public function getOpcion1(): ?string
    {
        return $this->opcion1;
    }

    public function setOpcion1(string $opcion1): static
    {
        $this->opcion1 = $opcion1;

        return $this;
    }

    public function getOpcion2(): ?string
    {
        return $this->opcion2;
    }

    public function setOpcion2(string $opcion2): static
    {
        $this->opcion2 = $opcion2;

        return $this;
    }

    public function getOpcion3(): ?string
    {
        return $this->opcion3;
    }

    public function setOpcion3(?string $opcion3): static
    {
        $this->opcion3 = $opcion3;

        return $this;
    }

    public function getOpcion4(): ?string
    {
        return $this->opcion4;
    }

    public function setOpcion4(?string $opcion4): static
    {
        $this->opcion4 = $opcion4;

        return $this;
    }

    public function getFechaInicio(): ?\DateTimeInterface
    {
        return $this->fecha_inicio;
    }

    public function setFechaInicio(\DateTimeInterface $fecha_inicio): static
    {
        $this->fecha_inicio = $fecha_inicio;

        return $this;
    }

    public function getFechaFin(): ?\DateTimeInterface
    {
        return $this->fecha_fin;
    }

    public function setFechaFin(\DateTimeInterface $fecha_fin): static
    {
        $this->fecha_fin = $fecha_fin;

        return $this;
    }

    public function getOpcionCorrecta(): ?string
    {
        return $this->opcion_correcta;
    }

    public function setOpcionCorrecta(string $opcion_correcta): static
    {
        $this->opcion_correcta = $opcion_correcta;

        return $this;
    }

    /**
     * @return Collection<int, Respuesta>
     */
    public function getRespuestas(): Collection
    {
        return $this->respuestas;
    }

    public function addRespuesta(Respuesta $respuesta): static
    {
        if (!$this->respuestas->contains($respuesta)) {
            $this->respuestas->add($respuesta);
            $respuesta->setIdPregunta($this);
        }

        return $this;
    }

    public function removeRespuesta(Respuesta $respuesta): static
    {
        if ($this->respuestas->removeElement($respuesta)) {
            // set the owning side to null (unless already changed)
            if ($respuesta->getIdPregunta() === $this) {
                $respuesta->setIdPregunta(null);
            }
        }

        return $this;
    }
}
