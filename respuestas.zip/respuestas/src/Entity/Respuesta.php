<?php

namespace App\Entity;

use App\Repository\RespuestaRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: RespuestaRepository::class)]
class Respuesta
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $contenido = null;

    #[ORM\Column(type: 'boolean')]
    private ?bool $correcta = null;

    #[ORM\ManyToOne(targetEntity: Pregunta::class, inversedBy: 'respuestas')]
    #[ORM\JoinColumn(name: 'id_pregunta', referencedColumnName: 'id', nullable: false)]
    private ?Pregunta $id_pregunta = null;

    #[ORM\ManyToOne(targetEntity: User::class, inversedBy: 'respuestas')]
    #[ORM\JoinColumn(name: 'id_user', referencedColumnName: 'id', nullable: false)]
    private ?User $id_user = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getContenido(): ?string
    {
        return $this->contenido;
    }

    public function setContenido(string $contenido): static
    {
        $this->contenido = $contenido;

        return $this;
    }

    public function isCorrecta(): ?bool
    {
        return $this->correcta;
    }

    public function setCorrecta(bool $correcta): static
    {
        $this->correcta = $correcta;

        return $this;
    }

    public function getIdPregunta(): ?Pregunta
    {
        return $this->id_pregunta;
    }

    public function setIdPregunta(?Pregunta $id_pregunta): static
    {
        $this->id_pregunta = $id_pregunta;

        return $this;
    }

    public function getIdUser(): ?User
    {
        return $this->id_user;
    }

    public function setIdUser(?User $id_user): static
    {
        $this->id_user = $id_user;

        return $this;
    }
}
