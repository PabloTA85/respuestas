<?php
namespace App\Entity;

use Symfony\Component\Security\Core\User\UserInterface;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use App\Entity\Respuesta;

#[ORM\Entity(repositoryClass: UserRepository::class)]
class User implements UserInterface
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $nombre = null;

    #[ORM\Column(length: 255)]
    private ?string $apellidos = null;

    #[ORM\Column(length: 255)]
    private ?string $correo = null;

    #[ORM\Column(length: 255)]
    private ?string $usuario = null;

    #[ORM\Column(length: 255)]
    private ?string $contraseña = null;

    #[ORM\Column(length: 255)]
    private ?string $rol = null;

    /**
     * @var Collection<int, Respuesta>
     */
    #[ORM\OneToMany(targetEntity: Respuesta::class, mappedBy: 'id_user', orphanRemoval: true)]
    private Collection $respuestas;

    public function __construct()
    {
        $this->respuestas = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNombre(): ?string
    {
        return $this->nombre;
    }

    public function setNombre(string $nombre): static
    {
        $this->nombre = $nombre;
        return $this;
    }

    public function getApellidos(): ?string
    {
        return $this->apellidos;
    }

    public function setApellidos(string $apellidos): static
    {
        $this->apellidos = $apellidos;
        return $this;
    }

    public function getCorreo(): ?string
    {
        return $this->correo;
    }

    public function setCorreo(string $correo): static
    {
        $this->correo = $correo;
        return $this;
    }

    public function getUsuario(): ?string
    {
        return $this->usuario;
    }

    public function setUsuario(string $usuario): static
    {
        $this->usuario = $usuario;
        return $this;
    }

    public function getContraseña(): ?string
    {
        return $this->contraseña;
    }

    public function setContraseña(string $contraseña): static
    {
        $this->contraseña = $contraseña;
        return $this;
    }

    public function getRol(): ?string
    {
        return $this->rol;
    }

    public function setRol(string $rol): static
    {
        $this->rol = $rol;
        return $this;
    }

    /**
     * @return Collection<int, Respuesta>
     */
    public function getRespuestas(): Collection
    {
        return $this->respuestas;
    }

    public function addRespuesta(Respuesta $respuesta): static
    {
        if (!$this->respuestas->contains($respuesta)) {
            $this->respuestas->add($respuesta);
            $respuesta->setIdUser($this);
        }

        return $this;
    }

    public function removeRespuesta(Respuesta $respuesta): static
    {
        if ($this->respuestas->removeElement($respuesta)) {
            if ($respuesta->getIdUser() === $this) {
                $respuesta->setIdUser(null);
            }
        }

        return $this;
    }

    // Métodos requeridos por UserInterface

    /**
     * Devuelve los roles del usuario
     */
    public function getRoles(): array
    {
        return [$this->rol]; // Puedes agregar más roles si es necesario
    }

    /**
     * Devuelve la contraseña cifrada del usuario
     */
    public function getPassword(): string
    {
        return $this->contraseña;
    }

    /**
     * Devuelve el nombre de usuario (por defecto el campo 'usuario')
     */
    public function getUsername(): string
    {
        return $this->usuario;
    }

    /**
     * Devuelve el salt utilizado para el cifrado de la contraseña
     */
    public function getSalt(): ?string
    {
        return null; // Si usas bcrypt, no necesitas un salt
    }

    /**
     * Limpia cualquier dato sensible
     */
    public function eraseCredentials(): void
    {
        // No es necesario borrar nada si la contraseña ya está cifrada
    }

    /**
     * Implementación de getUserIdentifier()
     */
    public function getUserIdentifier(): string
    {
        return $this->usuario;  // O puedes usar otro campo, como el correo electrónico
    }
}


