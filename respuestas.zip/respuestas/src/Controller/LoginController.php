<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Symfony\Bundle\SecurityBundle\Security;

class LoginController extends AbstractController
{
    /**
     * @Route("/login", name="login", methods={"GET", "POST"})
     */
    public function index(AuthenticationUtils $authenticationUtils)
    {
        
        // Si el usuario ya está autenticado, redirige a la página de preguntas
        if ($this->security->getUser()) {
            return $this->redirectToRoute('app_pregunta_show');
        }

        // Si no está autenticado, mostrar el formulario de login
        return $this->render('security/login.html.twig');
    }

    
}
