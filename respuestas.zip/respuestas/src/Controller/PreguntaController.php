<?php
// src/Controller/PreguntaController.php

namespace App\Controller;

use App\Entity\Pregunta;
use App\Repository\PreguntaRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class PreguntaController extends AbstractController
{
    /**
     * @Route("/pregunta/{id}", name="app_pregunta_show")
     */
    public function show(int $id, PreguntaRepository $preguntaRepository): Response
    {
        // Cargar la pregunta por su ID
        $pregunta = $preguntaRepository->find($id);

        if (!$pregunta) {
            throw $this->createNotFoundException('No question found for id ' . $id);
        }

        // Pasar la pregunta a la vista
        return $this->render('pregunta/show.html.twig', [
            'preguntum' => $pregunta,
        ]);
    }

    /**
     * @Route("/pregunta", name="app_pregunta_index")
     */
    public function index(PreguntaRepository $preguntaRepository): Response
    {
        // Cargar todas las preguntas desde la base de datos
        $preguntas = $preguntaRepository->findAll();

        // Pasar las preguntas a la vista
        return $this->render('pregunta/index.html.twig', [
            'preguntas' => $preguntas,
        ]);
    }
}
