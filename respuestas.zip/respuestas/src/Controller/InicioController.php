<?php
// filepath: /c:/xampp1/htdocs/Servidor/respuestas/src/Controller/InicioController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class InicioController extends AbstractController
{
    
    #[Route('/inicio', name: 'inicio')]
    public function inicio()
    {
        return $this->render('security/index.html.twig', [
            
        ]);
    }
}