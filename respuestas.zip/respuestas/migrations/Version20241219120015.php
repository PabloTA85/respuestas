<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20241219120015 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE respuesta DROP FOREIGN KEY FK_6C6EC5EE29B74DE9');
        $this->addSql('ALTER TABLE respuesta DROP FOREIGN KEY FK_6C6EC5EE79F37AE5');
        $this->addSql('DROP INDEX IDX_6C6EC5EE79F37AE5 ON respuesta');
        $this->addSql('DROP INDEX IDX_6C6EC5EE29B74DE9 ON respuesta');
        $this->addSql('ALTER TABLE respuesta ADD id_user INT NOT NULL, ADD id_pregunta INT NOT NULL, DROP id_user_id, DROP id_pregunta_id');
        $this->addSql('ALTER TABLE respuesta ADD CONSTRAINT FK_6C6EC5EE6B3CA4B FOREIGN KEY (id_user) REFERENCES user (id)');
        $this->addSql('ALTER TABLE respuesta ADD CONSTRAINT FK_6C6EC5EEFE3B0D62 FOREIGN KEY (id_pregunta) REFERENCES pregunta (id)');
        $this->addSql('CREATE INDEX IDX_6C6EC5EE6B3CA4B ON respuesta (id_user)');
        $this->addSql('CREATE INDEX IDX_6C6EC5EEFE3B0D62 ON respuesta (id_pregunta)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE respuesta DROP FOREIGN KEY FK_6C6EC5EE6B3CA4B');
        $this->addSql('ALTER TABLE respuesta DROP FOREIGN KEY FK_6C6EC5EEFE3B0D62');
        $this->addSql('DROP INDEX IDX_6C6EC5EE6B3CA4B ON respuesta');
        $this->addSql('DROP INDEX IDX_6C6EC5EEFE3B0D62 ON respuesta');
        $this->addSql('ALTER TABLE respuesta ADD id_user_id INT NOT NULL, ADD id_pregunta_id INT NOT NULL, DROP id_user, DROP id_pregunta');
        $this->addSql('ALTER TABLE respuesta ADD CONSTRAINT FK_6C6EC5EE29B74DE9 FOREIGN KEY (id_pregunta_id) REFERENCES pregunta (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('ALTER TABLE respuesta ADD CONSTRAINT FK_6C6EC5EE79F37AE5 FOREIGN KEY (id_user_id) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE INDEX IDX_6C6EC5EE79F37AE5 ON respuesta (id_user_id)');
        $this->addSql('CREATE INDEX IDX_6C6EC5EE29B74DE9 ON respuesta (id_pregunta_id)');
    }
}
