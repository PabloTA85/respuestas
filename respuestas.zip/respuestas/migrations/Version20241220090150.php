<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20241220090150 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE pregunta CHANGE fecha_inicio fecha_inicio DATETIME NOT NULL, CHANGE fecha_fin fecha_fin DATETIME NOT NULL, CHANGE correcta opcion_correcta VARCHAR(255) NOT NULL');
        $this->addSql('ALTER TABLE respuesta ADD id_user INT NOT NULL, ADD correcta TINYINT(1) NOT NULL, DROP pregunta_id, DROP fecha, CHANGE usuario_id id_pregunta INT NOT NULL, CHANGE respuesta contenido VARCHAR(255) NOT NULL');
        $this->addSql('ALTER TABLE respuesta ADD CONSTRAINT FK_6C6EC5EEFE3B0D62 FOREIGN KEY (id_pregunta) REFERENCES pregunta (id)');
        $this->addSql('ALTER TABLE respuesta ADD CONSTRAINT FK_6C6EC5EE6B3CA4B FOREIGN KEY (id_user) REFERENCES user (id)');
        $this->addSql('CREATE INDEX IDX_6C6EC5EEFE3B0D62 ON respuesta (id_pregunta)');
        $this->addSql('CREATE INDEX IDX_6C6EC5EE6B3CA4B ON respuesta (id_user)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE pregunta CHANGE fecha_inicio fecha_inicio DATETIME DEFAULT NULL, CHANGE fecha_fin fecha_fin DATETIME DEFAULT NULL, CHANGE opcion_correcta correcta VARCHAR(255) NOT NULL');
        $this->addSql('ALTER TABLE respuesta DROP FOREIGN KEY FK_6C6EC5EEFE3B0D62');
        $this->addSql('ALTER TABLE respuesta DROP FOREIGN KEY FK_6C6EC5EE6B3CA4B');
        $this->addSql('DROP INDEX IDX_6C6EC5EEFE3B0D62 ON respuesta');
        $this->addSql('DROP INDEX IDX_6C6EC5EE6B3CA4B ON respuesta');
        $this->addSql('ALTER TABLE respuesta ADD usuario_id INT NOT NULL, ADD pregunta_id INT DEFAULT NULL, ADD fecha DATETIME NOT NULL, DROP id_pregunta, DROP id_user, DROP correcta, CHANGE contenido respuesta VARCHAR(255) NOT NULL');
    }
}
